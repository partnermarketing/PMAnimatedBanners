window.pmAnimatedBannersConfig = function(conf) {
  conf.map({
    reference: 'logo',
    image: getPmData('image', 'partner.logo'),
    align: {
      x: 'center',
      y: 'center'
    }
  });
  conf.map({
    reference: 'stage',
    link: window.targetUrl
  });
};